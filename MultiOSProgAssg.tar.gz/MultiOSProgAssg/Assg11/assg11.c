/*
	Write a program which accept two file names from user and copy the
	contents of an existing file into newly created file.
*/

#include"header.h"

int main(int argc,char *argv[])
{

	int fd1,fd2,ret;
	char Arr[1024];
	printf("***************** Assignment - 11 *************\n");

	fd1=open(argv[1],O_RDONLY);

	if(fd1==-1)
	{
		printf("File not found ... \n");
		return -1;
	}

	fd2=open(argv[2],O_RDWR | O_CREAT);
	
	if(fd2==-1)
	{
		printf("File not successfully opened .. \n");
		close(fd1);
		return -1;
	}
	memset(Arr,0,sizeof(Arr));

	while((ret=read(fd1,Arr,sizeof(Arr)))!=0)
	{
		write(fd2,Arr,strlen(Arr));
		memset(Arr,0,sizeof(Arr));
	}

	close(fd1);
	close(fd2);

	return 0;
}
	

