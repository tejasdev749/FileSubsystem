/*
	Write a program which accept file name and mode from user and then
	open that file in specified mode.

*/


#include"header.h"

int main(int argc,char *argv[])
{
	int fd;
	
	printf("******************* Assignment - 2 *******************\n");

	if(argc!=3)
	{
		printf(" Invalid number of arguments \n");
		return -1;
	}

	if(strcmp(argv[2],"read")==0)
	{
		fd=open(argv[1],O_RDONLY);

		if(fd==-1)
		{
			printf(" File not found or read not allowed ..\n");
			return -1;
		}
		
		printf(" File successfully opened in read mode with file descriptor %d \n",fd);
	}
	else if(strcmp(argv[2],"write")==0)
	{
		fd=open(argv[1],O_WRONLY);
		
		if(fd==-1)
		{
			printf("File not found or write not allowed ..\n");
			return -1;
		}
		
		printf("File successfully opened in write mode with file descriptor %d \n",fd);
	}
	else if(strcmp(argv[2],"read-write")==0)
	{
		fd=open(argv[1],O_RDWR);
		
		if(fd==-1)
		{
			printf("File not found ..\n");
			return -1;
		}
	
		printf("File successfully opened in read-write mode with file descriptor %d \n",fd);
	}

	close(fd);
	return 0;
} 

			
			
