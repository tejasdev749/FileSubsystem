/*
	Write a program which accept directory name from user and print all
	file names and its types from that directory.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	int ret;

	char path[100];
	printf("**************** Assignment - 9 **************\n");
	
	
	
	

	dir=opendir(argv[1]);
	if(dir==NULL)
	{
		printf("Directory could not be opened ..\n");
		return -1;
	}
	
	while((entry=readdir(dir))!=NULL)
	{
		
		if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)
		{
			continue;
		}

		sprintf(path,"%s/%s",argv[1],entry->d_name);		
				
		ret=stat(path,&filestat);
				
		if(ret==-1)
		{
			printf(" stat function failed ..\n");

			perror("stat");
			continue;
		}		

		 
		if(S_ISREG(filestat.st_mode))
		{
			printf("File name %s\t -> File Type : Regular file \n",entry->d_name);		
		}
		else if(S_ISDIR(filestat.st_mode))
		{
			printf("File name %s\t -> File Type : Directory file \n",entry->d_name);		
		}
		
		

	}
	
	closedir(dir);

	return 0;
}


