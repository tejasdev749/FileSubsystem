/*
	Write a program which accept file name from user and write string
	in that file
*/

#include"header.h"

int main(int argc,char *argv[])
{

	int fd,ret;	
	char str[]="Hello World";

	printf("***************** Assignment - 7 ****************\n");
	
	
	fd=open(argv[1],O_RDWR | O_APPEND);

	if(fd==-1)
	{
		printf("File could not be opened ..\n");
		return -1;
	}

	write(fd,str,strlen(str));

	close(fd);

	return 0;
}

	
	
