/*
	Write a program which accept directory name from user and print
	name of such a file having largest size.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	long long int max=0;

	char path[100],filepath[100];	
	printf("************** Assignment - 10 ********************\n");

	dir=opendir(argv[1]);
	
	if(dir==NULL)
	{
		printf("Directory could not be opened ..\n");
		return -1;
	}

	while((entry=readdir(dir))!=NULL)
	{
		
		sprintf(path,"%s/%s",argv[1],entry->d_name);

		stat(path,&filestat);
		if(filestat.st_size>max)
		{
			max=filestat.st_size;
			strcpy(filepath,entry->d_name);
		}
	}

	printf("File with largest size %lld is\t :%s ",max,filepath); 		
	
	closedir(dir);

	return 0;
}


