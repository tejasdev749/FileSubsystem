/*
	Write a program which accept file name from user and read whole file.
*/


#include"header.h"

int main(int argc,char *argv[])
{

	int fd,ret;
	char Arr[256];
	printf("***************** Assignment - 6 ****************\n");

	
	fd=open(argv[1],O_RDONLY);

	if(fd==-1)
	{
		printf("File could not be opened ..\n");
		return -1;
	}

	memset(Arr,0,sizeof(Arr));

	while(ret=read(fd,Arr,sizeof(Arr))!=0)
	{
		printf("%s",Arr);
	}


	close(fd);

	return 0;
}
