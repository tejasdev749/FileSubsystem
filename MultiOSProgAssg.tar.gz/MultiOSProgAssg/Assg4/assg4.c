/*
	Write a program which accept file name from user and print all
	information about that file.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	struct stat filestat;	
	int ret;

	printf("***************** Assignment - 4 ******************\n");

	ret=stat(argv[1],&filestat);

	if(ret==-1)
	{
		printf(" stat function failed ..\n");
		return -1;
	}

	printf("File Inode number %ld \n",(long)filestat.st_ino);
	printf("File Size %ld \n",(long)filestat.st_size);
	printf("File Blocks allocated %ld \n",(long)filestat.st_blocks);
	printf("File Owner UID=%ld  GID=%ld \n",(long)filestat.st_uid,(long)filestat.st_gid);
	printf("File Last Access Time %s \n",ctime(&filestat.st_atime));
	printf("File Last Modification Time %s \n",ctime(&filestat.st_mtime));
	
	if(S_ISREG(filestat.st_mode))
	{
		printf("It is regular file \n");
	}

	return 0;
}
	
