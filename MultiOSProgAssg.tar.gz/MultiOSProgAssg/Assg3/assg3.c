/*
	Write a program which accept file name and on mode and that program
	check whether our process can access that file in accepted mode or
	not.
*/	

#include"header.h"

int main(int argc,char *argv[])
{

	struct stat filestat;
		
	printf("****************** Assgnment - 3 *******************");
	
	if(argc!=3)
	{
		printf(" Invalid number of arguments \n");
		return -1;
	}

	stat(argv[1],&filestat);
	
	if(strcmp(argv[2],"read")==0)
	{
		if(filestat.st_mode & S_IRUSR)
		{
			printf("File allowed to open in read mode\n");
		}
		else
		{
			printf("File not allowed to open in read mode\n");
		}
	}
	else if(strcmp(argv[2],"write")==0)
	{
		if(filestat.st_mode & S_IWUSR)
		{
	
			printf("File allowed to open in write mode\n");
		}
		else
		{
			printf("File not allowed to open in write mode\n");
		}
	}
	else if(strcmp(argv[2],"read-write")==0)
	{
		if(filestat.st_mode & S_IWUSR)
		{
			printf("File allowed to open in read-write mode\n");
		}
		else	
		{
			printf("File not allowed to open in read-write mode\n");
		}
	}

	return 0;
}
	
