#include<stdio.h>
#include<malloc.h>

void ArrayRev(int Arr[],int);

int main()
{
	int *ptr=NULL;
	int iCnt=0,iSize=0,iRet=0;


	printf("Enter Number of elements ");
		scanf("%d",&iSize);

	ptr=(int *)malloc(iSize*sizeof(int));

	for(iCnt=0;iCnt<iSize;iCnt++)
	{
		printf("Enter Number : %d ",iCnt+1);		
			scanf("%d",&ptr[iCnt]);
	}

	ArrayRev(ptr,iSize);
	printf("Array After Reverse \n");
	for(iCnt=0;iCnt<iSize;iCnt++)
	{
		printf("%d \t",ptr[iCnt]);			
	}

	return 0;
}

void ArrayRev(int Arr[],int ilength)
{

	int i=0,j=ilength-1,temp=0;

	while(i<j)
	{
		temp=Arr[i];
		Arr[i]=Arr[j];
		Arr[j]=temp;
		
		i++;
		j--;
	}
}























