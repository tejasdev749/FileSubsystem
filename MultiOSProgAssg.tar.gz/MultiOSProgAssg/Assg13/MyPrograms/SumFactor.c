#include<stdio.h>

int SumFactor(int);


int main()
{
	int no=12,ret=0;
	ret=SumFactor(no);
	printf("Difference is %d ",ret);

	return 0;
}


int SumFactor(int iNo)
{
	int i,iSum1=0,iSum2=0;


	for(i=1;i<=iNo;i++)
	{
		if(iNo%i==0)
		{
			iSum1=iSum1+i;
		}
		else
		{
			iSum2=iSum2+i;
		}
	}

	return (iSum1-iSum2);
}
