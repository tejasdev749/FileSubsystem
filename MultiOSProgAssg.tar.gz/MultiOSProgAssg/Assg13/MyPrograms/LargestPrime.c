#include<stdio.h>
#include<malloc.h>

int LargestPrime(int Arr[],int);

int main()
{
	int *ptr=NULL;
	int iCnt=0,iSize=0,iRet=0;


	printf("Enter Number of elements ");
		scanf("%d",&iSize);

	ptr=(int *)malloc(iSize*sizeof(int));

	for(iCnt=0;iCnt<iSize;iCnt++)
	{
		printf("Enter Number : %d ",iCnt+1);		
			scanf("%d",&ptr[iCnt]);
	}

	iRet=LargestPrime(ptr,iSize);
	printf("Largest Prime Number is %d",iRet);
		free(ptr);

	return 0;
}


int LargestPrime(int Arr[],int ilength)
{
	int iCnt=0,i=0,iMax=0,iSum=0;

	for(iCnt=0;iCnt<ilength;iCnt++)
	{

		for(i=2;i<=Arr[iCnt]/2;i++)
		{
			if(Arr[iCnt]%i==0)
			{
				break;
			}
		}
		if(i>=(Arr[iCnt]/2)+1)
		{
			printf(" %d ",Arr[iCnt]);
			iSum=iSum+Arr[iCnt];
			if(Arr[iCnt]>iMax)
			{
				iMax=Arr[iCnt];
			}
		}
	}
	return iMax;
}

	

















