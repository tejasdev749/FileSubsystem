/*
	Write a program which accept two directory names from user and
	move all files from source directory to destination directory.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	printf("*************** Assignment - 13 *****************\n");

		int ret=rename(argv[1],argv[2]);
		if(ret == -1)
		{
			printf("Unable to rename file\n");
			return -1;
		}

	return 0;
}	
	
