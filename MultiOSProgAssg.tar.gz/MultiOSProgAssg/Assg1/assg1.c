/*
	Write a program which accept file name from user and open that file.
*/



#include"header.h"

int main(int argc,char *argv[])
{
	int fd;	

	printf(" ****************** Assignment - 1 ****************** :\n");
	
	if(argc!=2)
	{
		printf("Invalid arguments ");
		return -1;
	}

	fd=open(argv[1],O_RDONLY);
	if(fd==-1)
	{
		printf(" File not found ..\n");
		return -1;
	}
		
	printf(" File opened successfully with file descriptor %d \n",fd);
	
	close(fd);
	return 0;
}
	

