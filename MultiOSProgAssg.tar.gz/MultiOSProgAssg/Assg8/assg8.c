/*
	Write a program which accept directory name from user and print all
	file names from that directory.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	printf("*****************Assignment - 8 ****************\n");


	dir=opendir(argv[1]);

	if(dir==NULL)
	{
		printf("Diretory could not be opened ..\n");
		return -1;
	}

	while((entry=readdir(dir))!=NULL)
	{
		if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)
		{
			continue;
		}

		printf("File name %s \n",entry->d_name);
	}

	closedir(dir);

	return 0;
}
