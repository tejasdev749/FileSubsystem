#include<stdio.h>


typedef long int LINT;

int main()
{
	LINT iNo1=652143042,iNo2=415062342;

	int Arr[10]={0};
	int Brr[10]={0};

	int digit=0,iCnt=0;
	LINT temp1=iNo1,temp2=iNo2;


	while(iNo1!=0)
	{
		digit=iNo1%10;
		Arr[digit]++;
		iNo1=iNo1/10;
	}
	iNo1=temp1;

	while(iNo2!=0)
	{
		digit=iNo2%10;
		Brr[digit]++;
		iNo2=iNo2/10;
	}
	iNo2=temp2;

	for(iCnt=0;iCnt<10;iCnt++)
	{
		if(Arr[iCnt]!=Brr[iCnt])
		{
			break;
		}
	}

	if(iCnt==10)
	{
		printf(" Number is Anagram Number ");
	}
	else
	{
		printf(" Number is not Anagram Number ");
	}

	return 0;

}

























		
