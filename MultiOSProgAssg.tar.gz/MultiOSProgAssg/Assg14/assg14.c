/*
	Write program which accept directory name from user and delete all
	empty files from that directory
*/

#include"header.h"

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char path[100];
	int ret;
	printf("************* Assignment - 14 ***************\n");

	dir=opendir(argv[1]);
	
	if(dir==NULL)
	{
		printf("Directory could not be opened .. \n");
		return -1;
	}

	while((entry=readdir(dir))!=NULL)
	{
		if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)
		{
			continue;	
		}

		sprintf(path,"%s/%s",argv[1],entry->d_name);
		
		stat(path,&filestat);

		if(filestat.st_blocks==0)
		{
			ret=unlink(path);
			if(ret==-1)
			{
				printf(" Unlink syaytem cal fails ...\n");
			}
		}
	}

	closedir(dir);

	return 0;
}

