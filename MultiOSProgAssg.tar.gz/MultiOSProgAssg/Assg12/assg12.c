/*
	Write a program which accept directory name and file name from
	user and check whether that file is present in that directory or not.
*/

#include"header.h"

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char path[100];
	printf("*************** Assignment - 12 *********************\n");

	dir=opendir(argv[1]);
	
	if(dir==NULL)
	{
		printf("Directory could not be opened ..\n");
		return -1;
	}

	while((entry=readdir(dir))!=NULL)
	{
		if(strcmp(entry->d_name,argv[2])==0)
		{
			break;
		}
	}
 	if(entry==NULL)
	{
		printf("File %s is not  present in %s Directory ..\n",argv[2],argv[1]);
	}
	else
	{
		printf("File %s present in %s Directory ..\n",argv[2],argv[1]);
	}

	closedir(dir);

	return 0;
}
