/*
	Write a program which accept file name and number of bytes from
	user and read that number of bytes from file.
*/

#include"header.h"

int main(int argc,char *argv[])
{

	printf("****************** Assignment - 5 *****************\n");
	int fd,ret;
	char Arr[256];
	
	char *str=argv[2];
	int i=0,no=0;
	while(str[i]!='\0')
	{
		no=no*10+str[i]-'0';
		i++;	
	}
	
	
		
	
	fd=open(argv[1],O_RDONLY);

	if(fd==-1)
	{
		printf("File could not be opened...");
		return -1;
	}
	memset(Arr,0,sizeof(Arr));
	ret=read(fd,Arr,no);
	
	printf("Number of bytes read is %d and Data is %s\n",ret,Arr);
	
	close(fd);

	return 0;
}
